<h1>You have a new contact!</h1>

<div>
	<?php echo e($bodyMessage); ?>

</div>

<p>Sent via <?php echo e($email); ?></p>
