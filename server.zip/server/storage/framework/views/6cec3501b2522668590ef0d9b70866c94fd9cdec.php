<!DOCTYPE html>
<html>
<head>
	<title>Test Mail</title>
</head>
<body>
	<p>This is the mail you get from me.</p>
</body>
</html>