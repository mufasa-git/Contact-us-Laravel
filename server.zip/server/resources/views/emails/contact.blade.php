<h1>You have a new contact!</h1>

<div>
	{{ $bodyMessage }}
</div>

<p>Sent via {{ $email }}</p>
